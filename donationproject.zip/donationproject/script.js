// Define a constant password for simplicity
const USERNAME = "donor";
const PASSWORD = "donor123"; // Replace with your desired password

function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Check if the entered credentials match the constant username and password
    if (username === USERNAME && password === PASSWORD) {
        alert("Login successful!");
        // Redirect to donation page
        window.location.href = "donate.html";
    } else {
        alert("Invalid credentials! Please try again.");
    }
}

function register() {
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const contact = document.getElementById("contact").value;
    const city = document.getElementById("city").value;

    // Check if all fields are filled
    if (!username || !email || !password || !confirmPassword || !contact || !city) {
        alert("Please fill in all fields.");
        return;
    }

    // Check if passwords match
    if (password !== confirmPassword) {
        alert("Passwords do not match. Please try again.");
        return;
    }

    // Simulate successful registration
    alert("Registration successful! You can now log in.");
    window.location.href = "index.html"; // Redirect to login page
}

function submitDonation() {
    const foodType = document.getElementById("foodType").value;
    const quantity = document.getElementById("quantity").value;

    // Store donation data
    const donation = { foodType, quantity, status: "Pending" };
    donations.push(donation);

    alert("Donation submitted successfully!");
    window.location.href = "admin.html";
}
function submitDonation() {
    // Redirect to the thank you page
    window.location.href = "thankyou.html";
}


function logout() {
    alert("You have successfully logged out.");
    // Redirect to the login page or home page if required
    // window.location.href = "login.html"; // Uncomment if you have a login page
}

